<?php


        $pdo = new PDO("mysql:host=localhost; user=root; dbname=stuff; charset=utf8mb4");
